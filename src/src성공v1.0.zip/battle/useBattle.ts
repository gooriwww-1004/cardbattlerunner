/**
 * useBattle.ts v2
 * 수정: 자동전투 (isAuto ON → 플레이어+NPC 모두 자동)
 * 수정: 수동모드 (플레이어 클릭, NPC 자동)
 * 수정: 스킬/마법 에디터 데이터 연동
 */
import { useState, useRef, useCallback, useEffect } from 'react';
import type { CardDefinition } from '../types';
import type { BattleState, BattleUnit, StatusEffect } from './BattleEngine';
import {
  initBattleState, calcDamage, tryTriggerSkill, getElemMul,
  applyDamage, applyHeal, applyStatus, tickStatuses,
  checkWinner, nextPhase, getAlive,
  canAttack, pickTarget,
} from './BattleEngine';

// ── 비주얼 유틸 ───────────────────────────────────────────
function showDmgFloat(el:HTMLElement,text:string,color='255,68,68'){
  const r=el.getBoundingClientRect();
  const d=document.createElement('div');
  d.style.cssText=`position:fixed;z-index:9999;pointer-events:none;
    left:${r.left+r.width/2}px;top:${r.top+r.height*0.15}px;
    transform:translateX(-50%) scale(0.8);font-size:22px;font-weight:900;
    color:rgb(${color});text-shadow:0 0 8px rgba(0,0,0,1);
    opacity:1;transition:transform 0.9s ease-out,opacity 0.9s;white-space:nowrap;`;
  d.textContent=text;document.body.appendChild(d);
  requestAnimationFrame(()=>{
    d.style.transform='translateX(-50%) translateY(-60px) scale(1.2)';
    d.style.opacity='0';
    setTimeout(()=>d.remove(),900);
  });
}

function showSkillFlash(el:HTMLElement,name:string){
  const r=el.getBoundingClientRect();
  const d=document.createElement('div');
  d.style.cssText=`position:fixed;z-index:9999;pointer-events:none;
    left:${r.left+r.width/2}px;top:${r.top-5}px;transform:translateX(-50%);
    font-size:11px;font-weight:700;white-space:nowrap;color:#fbbf24;
    background:rgba(0,0,0,0.85);border:1px solid rgba(251,191,36,0.5);
    border-radius:4px;padding:2px 8px;opacity:1;
    transition:transform 1.2s ease-out,opacity 1.2s;`;
  d.textContent=`✨ ${name}`;document.body.appendChild(d);
  requestAnimationFrame(()=>{
    d.style.transform='translateX(-50%) translateY(-40px)';d.style.opacity='0';
    setTimeout(()=>d.remove(),1200);
  });
}

function localFlash(el:HTMLElement,color='rgba(239,68,68,0.35)'){
  const r=el.getBoundingClientRect();
  const d=document.createElement('div');
  d.style.cssText=`position:fixed;z-index:9998;pointer-events:none;
    left:${r.left-12}px;top:${r.top-12}px;width:${r.width+24}px;height:${r.height+24}px;
    background:${color};border-radius:12px;opacity:1;transition:opacity 200ms;`;
  document.body.appendChild(d);
  requestAnimationFrame(()=>{
    setTimeout(()=>{d.style.opacity='0';setTimeout(()=>d.remove(),200);},30);
  });
}

function spawnParticles(el:HTMLElement,color='255,80,30',count=8){
  const r=el.getBoundingClientRect();
  const cx=r.left+r.width/2,cy=r.top+r.height/2;
  for(let i=0;i<count;i++){
    const ang=(360/count)*i,dist=20+Math.random()*30,sz=4+Math.random()*6;
    const rad=ang*Math.PI/180;
    const d=document.createElement('div');
    d.style.cssText=`position:fixed;z-index:9999;pointer-events:none;
      left:${cx-sz/2}px;top:${cy-sz/2}px;width:${sz}px;height:${sz}px;border-radius:50%;
      background:rgb(${color});opacity:1;transition:transform 0.4s ease-out,opacity 0.4s;`;
    document.body.appendChild(d);
    requestAnimationFrame(()=>{
      d.style.transform=`translate(${Math.cos(rad)*dist}px,${Math.sin(rad)*dist}px) scale(0)`;
      d.style.opacity='0';setTimeout(()=>d.remove(),400);
    });
  }
}

const SKILL_COLOR:Record<string,string>={
  damage:'255,80,30',damage_pen:'255,150,50',damage_aoe:'255,50,50',
  buff_atk:'34,197,94',buff_def:'59,130,246',heal:'34,197,94',
  drain:'168,85,247',debuff_atk:'239,68,68',debuff_def:'239,68,68',stun:'251,191,36',
};

function playSfx(url:string,vol=0.6){
  try{const a=new Audio(url);a.volume=vol;a.play().catch(()=>{});}catch{}
}

// ── 훅 ───────────────────────────────────────────────────
interface UseBattleProps {
  playerCards: CardDefinition[];
  npcCards: CardDefinition[];
  sfxOn?: boolean;
}

export function useBattle({playerCards,npcCards,sfxOn=true}:UseBattleProps){
  const [state,setState]=useState<BattleState>(()=>initBattleState(playerCards,npcCards));
  const [isAuto,setIsAuto]=useState(false);
  const [selectedUid,setSelectedUid]=useState<string|null>(null);

  // ── 예비 카드 (덱 후반부 → 대기창) ──────────────────────
  const [reservePlayer, setReservePlayer] = useState<BattleUnit[]>(()=>{
    const half = Math.ceil(playerCards.length / 2);
    return playerCards.slice(half).map((c,i)=>({
      card:c, uid:`rp${i}_${Date.now()}`,
      currentHp:c.health, isDead:false,
      side:'player' as const, squad:2 as const,
      row:0, col:i, statuses:[], skillCooldowns:{},
      equippedAbilities:(c as any).equippedAbilities??[],
    }));
  });
  const [reserveNpc, setReserveNpc] = useState<BattleUnit[]>(()=>{
    const half = Math.ceil(npcCards.length / 2);
    return npcCards.slice(half).map((c,i)=>({
      card:c, uid:`rn${i}_${Date.now()}`,
      currentHp:c.health, isDead:false,
      side:'npc' as const, squad:2 as const,
      row:0, col:i, statuses:[], skillCooldowns:{},
      equippedAbilities:(c as any).equippedAbilities??[],
    }));
  });

  // ── 별 게이지 ────────────────────────────────────────────
  const [starPlayer, setStarPlayer] = useState(0);
  const [starNpc,    setStarNpc]    = useState(0);
  const busyRef=useRef(false);
  const stateRef=useRef(state);
  useEffect(()=>{stateRef.current=state;},[state]);

  const addLog=(msg:string)=>setState(s=>({...s,log:[...s.log.slice(-60),msg]}));

  // ── 공격 실행 ───────────────────────────────────────────
  const doAttack=useCallback((atkUid:string,defUid:string,onDone:()=>void)=>{
    busyRef.current=true;
    const cur=stateRef.current;
    const allUnits=[...cur.playerUnits,...cur.npcUnits];
    const atk=allUnits.find(u=>u.uid===atkUid);
    const def=allUnits.find(u=>u.uid===defUid);
    if(!atk||!def||def.isDead){busyRef.current=false;onDone();return;}

    const isNpcAtk=atk.side==='npc';
    let dmg=calcDamage(atk,def);
    const mul=getElemMul(atk.card.element,def.card.element);
    const mulStr=mul>1?' 🔺':mul<1?' 🔻':'';

    // ── 스킬 발동 ─────────────────────────────────────────
    const sk=tryTriggerSkill(atk);
    if(sk){
      const atkEl=document.getElementById(`bu-${atkUid}`);
      if(atkEl){
        showSkillFlash(atkEl,sk.name);
        spawnParticles(atkEl,SKILL_COLOR[sk.effectType]||'251,191,36',6);
      }
      if(sfxOn) playSfx('/assets/audio/btn_sound05.mp3');

      setState(s=>{
        let pU=[...s.playerUnits],nU=[...s.npcUnits];
        switch(sk.effectType){
          // ── 에디터 effectType 별칭 포함 ──────────────────
          case 'damage': case 'damage_pen': case 'attack':
            dmg=Math.floor(dmg*(1+sk.power/100));
            addLog(`✨ ${atk.card.name}[${sk.name}] 데미지 +${sk.power}%`); break;
          case 'damage_aoe':
            dmg=Math.floor(dmg*(1+sk.power/100));
            addLog(`💥 ${atk.card.name}[${sk.name}] 광역!`); break;
          case 'buff_atk':
            if(isNpcAtk) nU=applyStatus(nU,atkUid,{type:'buff_atk',power:sk.power,turnsLeft:2});
            else         pU=applyStatus(pU,atkUid,{type:'buff_atk',power:sk.power,turnsLeft:2});
            addLog(`📈 ${atk.card.name}[${sk.name}] 공격력 +${sk.power}% 2턴`); break;
          case 'buff_def': case 'defense':
            if(isNpcAtk) nU=applyStatus(nU,atkUid,{type:'buff_def',power:sk.power,turnsLeft:2});
            else         pU=applyStatus(pU,atkUid,{type:'buff_def',power:sk.power,turnsLeft:2});
            addLog(`🛡️ ${atk.card.name}[${sk.name}] 방어력 +${sk.power}% 2턴`); break;
          case 'heal':{
            const amt=Math.floor(atk.card.health*sk.power/100);
            if(isNpcAtk) nU=applyHeal(nU,atkUid,amt);
            else         pU=applyHeal(pU,atkUid,amt);
            const el2=document.getElementById(`bu-${atkUid}`);
            if(el2) showDmgFloat(el2,`+${amt}`,'34,197,94');
            addLog(`💚 ${atk.card.name}[${sk.name}] HP +${amt}`); break;
          }
          case 'drain':{
            const damt=Math.floor(dmg*sk.power/100);
            if(isNpcAtk) nU=applyHeal(nU,atkUid,damt);
            else         pU=applyHeal(pU,atkUid,damt);
            addLog(`🩸 ${atk.card.name}[${sk.name}] 흡수 +${damt}`); break;
          }
          case 'debuff_atk':
            if(isNpcAtk) pU=applyStatus(pU,defUid,{type:'debuff_atk',power:sk.power,turnsLeft:1});
            else         nU=applyStatus(nU,defUid,{type:'debuff_atk',power:sk.power,turnsLeft:1});
            addLog(`📉 ${def.card.name} 공격력 -${sk.power}% 1턴`); break;
          case 'debuff_def':
            if(isNpcAtk) pU=applyStatus(pU,defUid,{type:'debuff_def',power:sk.power,turnsLeft:1});
            else         nU=applyStatus(nU,defUid,{type:'debuff_def',power:sk.power,turnsLeft:1});
            addLog(`📉 ${def.card.name} 방어력 -${sk.power}% 1턴`); break;
          case 'stun': case 'status':
            if(isNpcAtk) pU=applyStatus(pU,defUid,{type:'stun',power:0,turnsLeft:1});
            else         nU=applyStatus(nU,defUid,{type:'stun',power:0,turnsLeft:1});
            addLog(`⚡ ${def.card.name} 기절 1턴`); break;
          default:
            // 알 수 없는 타입 → 데미지 보너스로 처리
            dmg=Math.floor(dmg*1.2);
            addLog(`✨ ${atk.card.name}[${sk.name}]`); break;
        }
        // 쿨타임
        if(isNpcAtk) nU=nU.map(u=>u.uid===atkUid?{...u,skillCooldowns:{...u.skillCooldowns,[sk.id]:sk.cooldown??2}}:u);
        else         pU=pU.map(u=>u.uid===atkUid?{...u,skillCooldowns:{...u.skillCooldowns,[sk.id]:sk.cooldown??2}}:u);
        return{...s,playerUnits:pU,npcUnits:nU};
      });
    }

    const type=atk.card.attackType||'melee';
    const defEl=document.getElementById(`bu-${defUid}`);
    const atkEl=document.getElementById(`bu-${atkUid}`);

    const finish=()=>{
      setState(s=>{
        let pU=[...s.playerUnits],nU=[...s.npcUnits];
        if(def.side==='npc') nU=applyDamage(nU,defUid,dmg);
        else                 pU=applyDamage(pU,defUid,dmg);
        pU=tickStatuses(pU);nU=tickStatuses(nU);
        const winner=checkWinner({...s,playerUnits:pU,npcUnits:nU});
        const phase=winner?'result':nextPhase({...s,playerUnits:pU,npcUnits:nU});
        return{...s,playerUnits:pU,npcUnits:nU,winner,phase};
      });
      if(defEl){
        spawnParticles(defEl,
          type==='melee'?'255,80,30':type==='magic'?'168,85,247':'251,191,36',8);
        localFlash(defEl,
          type==='melee'?'rgba(239,68,68,0.3)':
          type==='magic'?'rgba(168,85,247,0.3)':'rgba(251,191,36,0.2)');
        showDmgFloat(defEl,`-${dmg}`);
      }
      if(sfxOn) playSfx(
        type==='melee'?'/assets/audio/btn_sound02.mp3':
        type==='ranged'?'/assets/audio/btn_sound03.mp3':
        '/assets/audio/btn_sound04.mp3'
      );
      const icon=type==='melee'?'⚔️':type==='magic'?'🪄':'🏹';
      addLog(`${icon} ${atk.card.name}→${def.card.name}: ${dmg}dmg${mulStr}`);
      busyRef.current=false;
      onDone();
    };

    // 근접 이동 애니메이션
    if(type==='melee'&&atkEl){
      const dir=isNpcAtk?'50px':'-50px';
      atkEl.style.transition='transform 0.18s ease-out';
      atkEl.style.transform=`translateY(${dir})`;
      setTimeout(()=>{
        atkEl.style.transition='transform 0.18s ease-in';
        atkEl.style.transform=`translateY(calc(${dir}*1.8))`;
        setTimeout(()=>{
          atkEl.style.transition='transform 0.2s ease-out';
          atkEl.style.transform='translateY(0)';
          finish();
        },180);
      },180);
    } else finish();
  },[sfxOn]);

  // ── 플레이어 수동 공격 ───────────────────────────────────
  const playerAttack=useCallback((atkUid:string,defUid:string)=>{
    if(state.turn!=='player'||busyRef.current) return;
    const cur=stateRef.current;
    const atk=cur.playerUnits.find(u=>u.uid===atkUid);
    const def=cur.npcUnits.find(u=>u.uid===defUid);
    if(!atk||!def) return;
    const check=canAttack(atk,def,[...cur.playerUnits,...cur.npcUnits]);
    if(!check.allowed){
      addLog(`🛡️ ${check.reason} — 공격 불가`); return;
    }
    setSelectedUid(null);
    doAttack(atkUid,defUid,()=>{
      setState(s=>{if(s.winner) return s; return{...s,turn:'npc',turnNum:s.turnNum+1};});
    });
  },[state.turn,doAttack]);

  // ── NPC 턴 ──────────────────────────────────────────────
  const doNpcTurn=useCallback(()=>{
    if(busyRef.current||stateRef.current.phase==='result') return;
    const cur=stateRef.current;
    const nAlive=getAlive(cur.npcUnits);
    const pAlive=getAlive(cur.playerUnits);
    if(!nAlive.length||!pAlive.length) return;
    const stunned=nAlive.find(u=>u.statuses.some(s=>s.type==='stun'));
    if(stunned){
      addLog(`⚡ ${stunned.card.name} 기절`);
      setState(s=>({...s,npcUnits:tickStatuses(s.npcUnits),playerUnits:tickStatuses(s.playerUnits),turn:'player'}));
      return;
    }
    const atk=nAlive.find(u=>u.card.position==='warrior')??nAlive[0];
    const preferred=pickTarget(atk,pAlive);
    if(!preferred) return;
    const check=canAttack(atk,preferred,[...cur.playerUnits,...cur.npcUnits]);
    const def=check.allowed?preferred:(pAlive.find(u=>u.row===0)??preferred);
    doAttack(atk.uid,def.uid,()=>{
      setState(s=>{if(s.winner) return s; return{...s,turn:'player'};});
    });
  },[doAttack]);

  const doPlayerAutoTurn=useCallback(()=>{
    if(busyRef.current||stateRef.current.phase==='result') return;
    const cur=stateRef.current;
    const pAlive=getAlive(cur.playerUnits);
    const nAlive=getAlive(cur.npcUnits);
    if(!pAlive.length||!nAlive.length) return;
    const atk=pAlive.find(u=>u.card.position==='warrior')??pAlive[0];
    const preferred=pickTarget(atk,nAlive);
    if(!preferred) return;
    const check=canAttack(atk,preferred,[...cur.playerUnits,...cur.npcUnits]);
    const def=check.allowed?preferred:(nAlive.find(u=>u.row===0)??preferred);
    doAttack(atk.uid,def.uid,()=>{
      setState(s=>{if(s.winner) return s; return{...s,turn:'npc',turnNum:s.turnNum+1};});
    });
  },[doAttack]);

  // ── 자동전투: isAuto ON → 양쪽 모두 자동 연속 ──────────
  useEffect(()=>{
    if(!isAuto||state.phase==='result'||busyRef.current) return;
    const delay=state.turn==='player'?600:900;
    const t=setTimeout(()=>{
      if(state.turn==='player') doPlayerAutoTurn();
      else doNpcTurn();
    },delay);
    return()=>clearTimeout(t);
  },[isAuto,state.turn,state.phase,doPlayerAutoTurn,doNpcTurn]);

  // ── 수동모드: NPC 턴만 자동 ─────────────────────────────
  useEffect(()=>{
    if(isAuto||state.turn!=='npc'||state.phase==='result'||busyRef.current) return;
    const t=setTimeout(doNpcTurn,900);
    return()=>clearTimeout(t);
  },[isAuto,state.turn,state.phase,doNpcTurn]);

  const placeUnit=useCallback((uid:string,squad:1|2,row:number,col:number)=>{
    // 예비 카드인지 확인
    const isReserve = reservePlayer.some(u=>u.uid===uid);
    if(isReserve){
      // 예비 → 필드 배치
      const unit=reservePlayer.find(u=>u.uid===uid); if(!unit) return;
      setState(s=>({...s,playerUnits:[...s.playerUnits,{...unit,squad,row,col}]}));
      setReservePlayer(p=>p.filter(u=>u.uid!==uid));
    } else {
      // 필드 내 이동
      setState(s=>({...s,playerUnits:s.playerUnits.map(u=>u.uid===uid?{...u,squad,row,col}:u)}));
    }
  },[reservePlayer]);

  // ── 예비 카드 → 필드 배치 ────────────────────────────────
  const addFromReserve=useCallback((uid:string, side:'player'|'npc')=>{
    if(side==='player'){
      const unit=reservePlayer.find(u=>u.uid===uid); if(!unit) return;
      // 빈 슬롯 찾기
      const cur=stateRef.current.playerUnits;
      let placed=false;
      for(let row=0;row<3&&!placed;row++) for(let col=0;col<4&&!placed;col++){
        if(!cur.find(u=>u.squad===1&&u.row===row&&u.col===col&&!u.isDead)){
          setState(s=>({...s,playerUnits:[...s.playerUnits,{...unit,squad:1,row,col}]}));
          setReservePlayer(p=>p.filter(u=>u.uid!==uid));
          placed=true;
        }
      }
    } else {
      const unit=reserveNpc.find(u=>u.uid===uid); if(!unit) return;
      const cur=stateRef.current.npcUnits;
      let placed=false;
      for(let row=0;row<3&&!placed;row++) for(let col=0;col<4&&!placed;col++){
        if(!cur.find(u=>u.squad===1&&u.row===row&&u.col===col&&!u.isDead)){
          setState(s=>({...s,npcUnits:[...s.npcUnits,{...unit,squad:1,row,col}]}));
          setReserveNpc(p=>p.filter(u=>u.uid!==uid));
          placed=true;
        }
      }
    }
  },[reservePlayer,reserveNpc]);

  // ── 별 게이지: 턴마다 +1 ─────────────────────────────────
  useEffect(()=>{
    if(state.phase==='result') return;
    if(state.turn==='player') setStarPlayer(s=>s+1);
    else                      setStarNpc(s=>s+1);
  },[state.turnNum]);

  const advancePhase=useCallback(()=>{
    setState(s=>({...s,phase:nextPhase(s)}));
  },[]);

  return{
    state,isAuto,setIsAuto,
    selectedUid,setSelectedUid,
    isBusy:busyRef.current,
    playerAttack,doNpcTurn,
    placeUnit,advancePhase,
    reservePlayer,reserveNpc,addFromReserve,
    starPlayer,starNpc,
  };
}